import csv
import re

wordslist = []
filename = "текст.TXT"
file = open(filename, "r", encoding="UTF-8")
reader = csv.reader(file, delimiter=' ')

for string in reader:
    for word in string:
        word = re.sub("[.]", '', word)
        wordslist.append(word)

file.close()
resultmax = max(len(x) for x in wordslist)
resultmin = min(len(x) for x in wordslist)
resultavg = sum(len(x) for x in wordslist) / len(wordslist)
print(resultavg)