import csv


def printfilelines(filename):
    text_file = open(filename, "r", encoding="UTF-8")
    reader = csv.reader(text_file, delimiter="\t")

    for string in reader:
        print(string)

    text_file.close()

print("1 група")
printfilelines('1 група.TXT')

print("2 група")
printfilelines('2 група.TXT')

print('3 група')
printfilelines('3 група.TXT')
