import csv


def writenames(filename, num_of_students):
    file = open(filename, "w+", encoding="UTF-8")

    for i in range(num_of_students):
        name = input("Enter name of the student: ")
        mark = input("Enter mark of the student:")
        file.write(name)
        file.write(' ' + mark + '\n')

    file.close()

print("1 група")
writenames('1 група.TXT', 3)

#print("2 група")
#writenames('2 група.TXT', 2)

#print('3 група')
#writenames('3 група.TXT', 2)
