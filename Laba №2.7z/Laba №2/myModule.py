def quick_sort(nums):
    """Sorting the list using quick sort algorithm"""
    if len(nums) <= 1:
        return nums

    fundamental_element = nums[0]
    less_then_fundamental = [i for i in nums if i < fundamental_element]
    central = list(filter(lambda x: x == fundamental_element, nums))
    bigger_then_fundamental = [i for i in nums if i > fundamental_element]

    return quick_sort(less_then_fundamental) + central + quick_sort(bigger_then_fundamental)


def search(nums, element):
    """Search for particular element"""
    for num in nums:
        if num == element:
            return nums.index(num)


def search_for_group_of_elements(nums, group_of_elements):
    """Search for group of elements"""
    for element in group_of_elements:
        search(nums, element)


def search_for_minimal(nums):
    """Search for first five minimal nums"""
    quick_sort(nums)
    return nums[0:5]


def search_for_max(nums):
    """Search for first five maximal nums"""
    quick_sort(nums).reverse()
    return nums[0:5]


def avg(nums):
    """Search for average num"""
    return sum(nums) / len(nums)


def onlyone(nums):
    """Clearing the list from copies of existing nums"""
    result = []
    for num in nums:
        if num not in result:
            result.append(num)
    return result
