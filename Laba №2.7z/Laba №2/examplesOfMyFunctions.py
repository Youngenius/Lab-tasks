import myModule as my

nums = [3, 4, -5, 6, 3, 1]
some_numbers = [3, 1, 0]

print(my.quick_sort(nums))
print(my.search(nums, 3))
print(my.onlyone(nums))
print(my.avg(nums))
print(my.search_for_max(nums))
print(my.search_for_minimal(nums))
print(my.search_for_group_of_elements(nums, some_numbers))
