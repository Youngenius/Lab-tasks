# Task 1
import math
import random

x = float(input("Enter x:"))
y = float(input("Enter y:"))

z = math.cos(x)**2 + math.sin(y)**2
print(z)

# Task 2
n = int(input("Enter N:"))

sum = 0
for i in range(n + 1):
    sum += i**2

print(sum)

# Task 3
exampleList = []

for i in range(n):
    exampleList.append(random.randint(-100, 100))

print(exampleList)
print(max(exampleList))

listProduct = 1
for i in exampleList:
    listProduct *= i

print(listProduct)

exampleList = [x for x in exampleList if x >= 0 ]
print(exampleList)
